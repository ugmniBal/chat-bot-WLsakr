export const metadata = {
  title: 'REVO 챗봇',
  description: 'Recycling info chatbot',
};

export default function RootLayout({ children }) {
  return (
    <html lang="ko">
      <body>{children}</body>
    </html>
  );
}